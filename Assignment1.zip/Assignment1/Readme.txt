#Assignment 1
Name: Vinay Chhabra
Student ID- 500228151

Program: 

Temperature Converter from Celsius to Fahrenheit

Formula for conversion:

Temp (℉) = (9t / 5) + 32